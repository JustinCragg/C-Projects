Fuzzy Logic Artificial Intelligence (flai)

-------------------------------------------------------------------------------------------------------------
	Folder/File Setup
The project must have a folder named 'scripts' in the build directory.
Inside the folder must be two seperate folders named 'agents' and 'resources'.
These folders will contain the scripts used for generating agents and resources for use in the project.
In order for the flai libraries to use the scripts a .script file must be placed in the corresponding folder.

-------------------------------------------------------------------------------------------------------------
	Script Setup
 - Sets the name of the object type
	SET_TYPE "name"
 - Sets the colour of the object
	SET_COLOUR 'r' 'g' 'b'
		***** Agents
A specific structure must be used for agent .script files
An agent script must begin with a SET_TYPE followed by the name of the agent type.
The SET_NEEDS command must be written before any other commands which reference a need
There must be a set og SET_FUNCTIONS commands written  for both distance and appeal
The SET_APPEAL command should only be used after all needs have had their functions set - using SET_FUNCTIONS.
 - Sets the types of needs the agent will require to survive
	SET_NEEDS "resource name"/"agent name" ... "resource name"/"agent name"
 - Sets the rate at which the agent's need decays
	SET_DECAY 'amount per second'
 - Sets the membership functions which the agent uses to determine how much a need is needed
	SET_FUNCTIONS "need name" MerbershipFunction
		Membership Functions
		LEFT_SHOULDER "function name" 'top' 'bottom'
		RIGHT_SHOULDER "function name" 'bottom' 'top'
		TRIANGLE "function name" 'bottom' 'top' 'bottom'
		TRAPEZOID "function name" 'bottom' 'plateu begin' 'plateu end' 'bottom'
 - Sets how the appeal of a need is determined
SET_APPEAL "need name" "appeal name" "need"/command
		Commands
		AND "need"/command "need"/command
		OR "need"/command "need"/command
		NOT "need"/command
		***** Resources
So long as the first line written is SET_TYPE no other order is needed
 - Sets the maximum amount of the resource is stored. A value of 'infinity' will not reduce when consumed by agents
	SET_QUANTITY 'max'
 - Sets the rate at which the resource recovers
	SET_REGROWTH 'growth per sec'
 - Sets the rate at which this resource is gathered
	SET_GATHER_AMOUNT 'gather per sec'

-------------------------------------------------------------------------------------------------------------
	Project Setup
To use the libary you will need an flai::GameManager object.
Each frame the gameManager's update and draw function will need to be called. Both of these functions are virutal and can be overridden.
To create an agent or resource you need to call the createObject function from the gameManager, which will return a SceneObject* pointer.
This will need to be cast to the respective type (flai::BaseResource* or flai::BaseAgent) and then initialised with its init function.
In order to reload scripts during runtime the gameManager's reloadScripts function will need to be called.